#include <iostream>
#include <string>
using namespace std;

// Blueprint for a single student record
struct Student {
    int id;
    string name;
    int semester;
    float cgpa;
};

class A_FRAME {
private:
    Student records[100]; // Fixed array for 100 students
    int count;           // Tracks number of records

public:
    A_FRAME() {
        count = 0;
    }

    // Function to add a new record
    void enrollStudent() {
        if (count >= 100) {
            cout << "Storage limit reached!" << endl;
            return;
        }

        cout << "Enter Student ID: ";
        cin >> records[count].id;
        cin.ignore(); // Clears buffer for string input

        cout << "Enter Student Name: ";
        getline(cin, records[count].name);

        cout << "Enter Semester: ";
        cin >> records[count].semester;

        cout << "Enter CGPA: ";
        cin >> records[count].cgpa;

        count++;
        cout << "Record saved successfully!" << endl;
    }

    // Function to show all records
    void listAllStudents() {
        if (count == 0) {
            cout << "No records found in the system." << endl;
            return;
        }

        cout << "\n--- Student Database ---" << endl;
        for (int i = 0; i < count; i++) {
            cout << "ID: " << records[i].id << " | Name: " << records[i].name 
                 << " | Sem: " << records[i].semester << " | CGPA: " << records[i].cgpa << endl;
        }
    }

    // Function to find a specific record
    void findStudentById() {
        int searchId;
        cout << "Enter ID to search: ";
        cin >> searchId;

        for (int i = 0; i < count; i++) {
            if (records[i].id == searchId) {
                cout << "Match Found!" << endl;
                cout << "Name: " << records[i].name << " | CGPA: " << records[i].cgpa << endl;
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    // Function to remove a record and shift others
    void discardRecord() {
        int targetId;
        cout << "Enter ID to remove: ";
        cin >> targetId;

        for (int i = 0; i < count; i++) {
            if (records[i].id == targetId) {
                // Logic to shift remaining items left
                for (int j = i; j < count - 1; j++) {
                    records[j] = records[j + 1];
                }
                count--;
                cout << "Record removed successfully." << endl;
                return;
            }
        }
        cout << "ID not found." << endl;
    }

    // User Interface Menu
    void startSystem() {
        int choice;
        do {
            cout << "\n===== A_FRAME DATABASE SYSTEM =====" << endl;
            cout << "1. Enroll Student" << endl;
            cout << "2. List All Students" << endl;
            cout << "3. Find Student by ID" << endl;
            cout << "4. Discard Record" << endl;
            cout << "5. Exit" << endl;
            cout << "Selection: ";
            cin >> choice;

            switch (choice) {
                case 1: enrollStudent(); break;
                case 2: listAllStudents(); break;
                case 3: findStudentById(); break;
                case 4: discardRecord(); break;
                case 5: cout << "Exiting system..." << endl; break;
                default: cout << "Invalid choice!" << endl;
            }
        } while (choice != 5);
    }
};

int main() {
    A_FRAME system;
    system.startSystem();
    return 0;
}
